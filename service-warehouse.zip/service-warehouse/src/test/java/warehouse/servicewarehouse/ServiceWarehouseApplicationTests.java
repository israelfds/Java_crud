package warehouse.servicewarehouse;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ServiceWarehouseApplicationTests {

	@Test
	void contextLoads() {
	}

}

package appstore.servicestore;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ServiceStoreApplication {

	public static void main(String[] args) {
		SpringApplication.run(ServiceStoreApplication.class, args);
	}

}

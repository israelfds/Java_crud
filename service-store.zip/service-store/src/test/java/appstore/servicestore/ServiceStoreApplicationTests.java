package appstore.servicestore;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ServiceStoreApplicationTests {

	@Test
	void contextLoads() {
	}

}
